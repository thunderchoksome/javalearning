class Int60ToHex3d{
	public static void main (String[] args){
		int num1=60;
		int num2=num1 & 15;//��ȡ����λ
		String str1=(num2>9)?(char)(num2-10+'A')+"":(num2+"");
		int temp=num1>>4;
		num2=temp & 15;
		String str2=(num2>9)?((char)(num2-10+'A')+""):(num2+"");
		System.out.println(str2+""+str1);
		
	}	
}