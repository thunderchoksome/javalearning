package com.liufu.contacts;

import java.util.Scanner;

/**
 * 
 * @author liufu
 * 创建一个长度为6的int型数组，要求取值为1-30，同时元素值各不相同
 * 输出最大值，计算平均值，输出最小值的索引
 */
public class ArrayTest {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("请输入所要创建的int数组的长度");
		int size=scan.nextInt();
		int[] arr=new int[size];
		int maxNum=0,minIndex=0,average=0,sum=0,min;
		for(int i=0;i<arr.length;i++) {
			arr[i]=(int)(Math.random()*(30-1+1)+1);
			for(int j=0;j<i;j++) {
				if(arr[i]==arr[j]) {
					arr[i]=(int)(Math.random()*(30-1+1)+1);
					j=0;
				}
			}	
		}
		min=arr[0];
		for(int i=0;i<arr.length;i++) {
			sum+=arr[i];
			if(arr[i]>maxNum) {
				maxNum=arr[i];
			}
			if(arr[i]<min) {
				min=arr[i];
				minIndex=i;
			}
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.println("最大值为"+maxNum);
		System.out.println("最小值索引为"+minIndex);
		average=sum/size;
		System.out.println("平均值为"+average);
	}
}
