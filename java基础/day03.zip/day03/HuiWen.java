package com.liufu.contacts;
/**
 * 回形数格式方阵的实现
	从键盘输入一个整数（1~20） 
	则以该数字为矩阵的大小，把1,2,3…n*n 的数字按照顺时针螺旋的形式填入其中。例如： 输入数字2，则程序输出： 1 2 
	4 3 
	输入数字3，则程序输出： 1 2 3 
	8 9 4 
	7 6 5 
	输入数字4， 则程序输出： 
	1   2   3   4 
	12  13  14  5 
	11  16  15  6 
	10   9  8    7
 */
import java.util.Scanner;

public class huiWen {
	
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("请输入回形方阵的大小");
		int size=scan.nextInt();
		int maxNum=size*size;
		//创建并初始化数组
		int[][] arr=new int[size][size];
		//给数组元素赋值
		int way=1;//way 为方向1：右 2：下3：左4：上
		int rightm=size-1,leftn=0,upn=0,downm=size-1;
		int j=0,i=0,num=1;
		while(rightm>=leftn) {
			if(num>maxNum) break;
			switch(way) {
			
			case 1:if(j<=rightm) {
						arr[i][j]=num;
						num++;
						j++;
					}else {
						j--;
						way=2;
						i++;
						rightm--;
					}break;
			case 2:if(i<=downm) {
						arr[i][j]=num;
						num++;
						i++;}
						else {
							i--;
							way=3;
							j--;
							downm--;
						}
					break;
			case 3:if(j>=leftn) {
						arr[i][j]=num;
						num++;
						j--;
					}else {
						j++;
						i--;
						leftn++;
						way=4;
					}break;
			case 4:if(i>upn) {
						arr[i][j]=num;
						num++;
						i--;
					}else {
						i++;
						j++;
						upn++;
						way=1;
					}break;
				
			}
				   
			
		}
		//显示回文方阵
		for(int a=0;a<size;a++) {
			for(int b=0;b<size;b++) {
				System.out.print(arr[a][b]+" ");
			}
			System.out.println();
		}
	}	
}
