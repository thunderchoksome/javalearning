package com.liufu.contacts;

import java.util.Scanner;

/**
 * 
 * @author 66husband
 * 杨辉三角的输出
 */
public class yangHui {
	public static void main(String[] args) {
		System.out.println("请输入所需打印出的杨辉三角的行数");
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		//1.creat a array[][]
		int[][] arr=new int[num][];
		for(int i=0;i<arr.length;i++) {
			arr[i]=new int[i+1];
		}
		//2.change the data
		for(int i=0;i<arr.length;i++) {
			arr[i][0]=arr[i][i]=1;
			if(i>1) {
				for(int j=1;j<arr[i].length-1;j++) {
					arr[i][j]=arr[i-1][j-1]+arr[i-1][j];
				}
			}
		}
		
		//3.check it over
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
}
